#pragma once
enum class Direction{ Right = 0, Left };